package com.khare.goku.searchbooks;

import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONStringer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;

public class FetchBookData {

  private String Image="https://books.google.com/books/content?id=vhWMAgAAQBAJ&printsec=frontcover&img=1&zoom=2&edge=curl&source=gbs_api";
  private   URL book_url;
    public ArrayList<CustomArrayList> fetchData(String url){
        try {
            book_url=new URL(url);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        String jsonresponse=makeHttpRequest(book_url);
        ArrayList<CustomArrayList> list;
        list = extractFeatureFromjson(jsonresponse);
        return  list;
    }
    private ArrayList<CustomArrayList> extractFeatureFromjson(String jsonresponse) {
        if(TextUtils.isEmpty(jsonresponse))
        return null;
        ArrayList<CustomArrayList> customArrayLists=new ArrayList<>();
        String bookimage,author,total,buy;
        float bookstar;
              try {
                JSONObject basejsonObject=new JSONObject(jsonresponse);
                  JSONArray baseArray;
                   int totalItem=basejsonObject.getInt("totalItems");
                if(totalItem!=0){
                    try {
                        baseArray = basejsonObject.getJSONArray("items");
                    }catch (org.json.JSONException f){
                    return null;}
                    for(int i=0;i<40;i++){
                      JSONObject childObject=baseArray.getJSONObject(i);
                      bookimage=childObject.getString("id");
                      JSONObject volumeArray=childObject.getJSONObject("volumeInfo");
                      JSONObject jsonbookPrice=childObject.getJSONObject("saleInfo");
                      String preview=volumeArray.getString("previewLink");
                      String info=volumeArray.getString("infoLink");
                      String title = volumeArray.getString("title");
                      String findSale=jsonbookPrice.getString("saleability");
                        if(findSale.equals("FOR_SALE")) {
                            JSONObject bookpriceObject = jsonbookPrice.getJSONObject("retailPrice");
                            String price = bookpriceObject.getString("amount");
                            String code = bookpriceObject.getString("currencyCode");
                            buy = jsonbookPrice.getString("buyLink");
                            total = code + " " + price;
                        }else{
                            total="Not for sale";
                            buy=null;
                        }
                      try{
                          bookstar=(float)volumeArray.getDouble("averageRating");
                      }catch(org.json.JSONException e){
                         bookstar=0;
                      }
                      try{
                      JSONArray authorArray = volumeArray.getJSONArray("authors");
                      author=authorArray.getString(0);}
                      catch (org.json.JSONException e){
                          author="Not found";
                      }
                      customArrayLists.add(new CustomArrayList(title,"By- "+author,Image.replace("vhWMAgAAQBAJ",bookimage),preview,info,total,buy,bookstar,totalItem));
                 }
          }else{
                    return null;
                }
              } catch (JSONException e) {
                e.printStackTrace();
            }
        return customArrayLists;
    }

    private String makeHttpRequest(URL book_url) {
        String jsonresponse="";
        if(book_url==null){
            return jsonresponse;
        }
        HttpURLConnection httpURLConnection=null;
        InputStream inputStream=null;
        try {
            httpURLConnection=(HttpURLConnection)book_url.openConnection();
            httpURLConnection.setReadTimeout(10000);
            httpURLConnection.setConnectTimeout(15000);
            httpURLConnection.setRequestMethod("GET");
            httpURLConnection.connect();

            if(httpURLConnection.getResponseCode()==200){
                inputStream=httpURLConnection.getInputStream();

                jsonresponse=readFromStream(inputStream);
            } else {

            }
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if (httpURLConnection!= null) {
               httpURLConnection.disconnect();
            }
            if (inputStream != null) {
                // Closing the input stream could throw an IOException, which is why
                // the makeHttpRequest(URL url) method signature specifies than an IOException
                // could be thrown.
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
return jsonresponse;

    }

    private String readFromStream(InputStream inputStream) throws IOException {
        StringBuilder builder=new StringBuilder();
        if(inputStream!=null){
            InputStreamReader reader=new InputStreamReader(inputStream, Charset.forName("UTF-8"));
            BufferedReader bufferedReader=new BufferedReader(reader);
            String line=bufferedReader.readLine();
            while (line!=null){
                builder.append(line);
                line=bufferedReader.readLine();
            }

              }
        return builder.toString();

    }

}
