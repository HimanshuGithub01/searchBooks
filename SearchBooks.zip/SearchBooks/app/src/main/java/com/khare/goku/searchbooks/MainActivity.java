package com.khare.goku.searchbooks;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity{

    private EditText text_search;//book to be searched

    private TextView showNum;//Textview for number of books

    private ImageView search_button;//Image of book

    private String get_String;//value to be searched

    private TextView NUMOFBOOKS;//total books found

    private String BOOKS_API="https://www.googleapis.com/books/v1/volumes?q=";//Google book api

    private String NEW_BOOK_API;//final api

    private  CustomAdapter adapter;//Adapter for custom array list

    ProgressBar listProgressBar;

    private TextView bookText;//center text1

    TextView booktext2;

    private Button showMore;//button to show more item

     ListView listView=null;//list view

    private int increase=0;
        private int temp=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bookText=findViewById(R.id.textBook);

        booktext2=findViewById(R.id.textBook2);

        showMore=findViewById(R.id.more);

        showMore.setVisibility(View.INVISIBLE);

        String msg=bookText.getText().toString();

     //  bookText.setText("\""+msg);

      // String msg2=booktext2.getText().toString();

        //booktext2.setText(msg2+"\"");

        text_search = findViewById(R.id.textSearch);

        showNum = findViewById(R.id.showNum);

        search_button = findViewById(R.id.searchbutton);

        listView = findViewById(R.id.mobile_list);

        NUMOFBOOKS = findViewById(R.id.totalBooks);

        listProgressBar=findViewById(R.id.progressBar);

        listProgressBar.setVisibility(View.INVISIBLE);

        adapter = new CustomAdapter(this, new ArrayList<CustomArrayList>());

        listView.setAdapter(adapter);
        AdView adView = (AdView) findViewById(R.id.adView);
        adView.setAdListener(new ToastAdListener(this));
        AdRequest adRequest = new AdRequest.Builder()
                .setRequestAgent("android_studio:ad_template").build();
        adView.loadAd(adRequest);

        showMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ConnectivityManager connect=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
                if(connect.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState()== NetworkInfo.State.CONNECTED||connect.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState()==NetworkInfo.State.CONNECTED) {
                 if(!get_String.isEmpty()&&get_String.equals(text_search.getText().toString())){
                  temp=1;
                adapter.clear();
                listProgressBar.setVisibility(View.VISIBLE);
                increase=increase+40;
                showBooks(increase);}
                else{
                   Toast.makeText(MainActivity.this, "Books not found", Toast.LENGTH_SHORT).show();
                    }
                }else{
                    Toast.makeText(MainActivity.this, "You are not connected to a network ", Toast.LENGTH_SHORT).show();
                }
          }
        });
        search_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
         increase=0;
                 temp=2;
                ConnectivityManager connect=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
                if(connect.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState()== NetworkInfo.State.CONNECTED||connect.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState()==NetworkInfo.State.CONNECTED) {
                    showBooks(0);
                }else{
                    Toast.makeText(MainActivity.this, "You are not connected to a network ", Toast.LENGTH_SHORT).show();
                }

            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                       CustomArrayList customArrayList = adapter.getItem(i);
                       if(customArrayList.getBook_buy()!=null){
                       Uri bookuri=Uri.parse(customArrayList.getBook_buy());
                       Intent bookIntent=new Intent(Intent.ACTION_VIEW,bookuri);
                       startActivity(bookIntent);}
                       else{
                           Toast.makeText(MainActivity.this, "Not Available", Toast.LENGTH_SHORT).show();
                       }
            }
        });
    }

    public class BookAsync extends AsyncTask<String,Void,List<CustomArrayList>>{

        @Override
        protected List<CustomArrayList> doInBackground(String... strings) {
            List<CustomArrayList> arrayList=new FetchBookData().fetchData(strings[0]);
            return arrayList;

        }

        @Override
        protected void onPostExecute(List<CustomArrayList> customArrayList) {

            listProgressBar.setVisibility(View.INVISIBLE);
            if(customArrayList!=null){
                showMore.setVisibility(View.VISIBLE);
                adapter.clear();
                showNum.setVisibility(View.VISIBLE);
                NUMOFBOOKS.setVisibility(View.VISIBLE);
                adapter.addAll(customArrayList);
                if(temp!=1){
                showNum.setText("Total Books found: ");
                NUMOFBOOKS.setText(new Integer(CustomArrayList.getBook_total()).toString());}
            }
            else{
                adapter.clear();
                showNum.setVisibility(View.INVISIBLE);
                NUMOFBOOKS.setVisibility(View.INVISIBLE);
                showMore.setVisibility(View.GONE);
                bookText.setVisibility(View.VISIBLE);
                booktext2.setVisibility(View.VISIBLE);

                Toast.makeText(MainActivity.this, "Books Not found", Toast.LENGTH_LONG).show();
            }
        }
    }
    public void showBooks(int i){
            get_String = (String) text_search.getText().toString();
            if(!get_String.isEmpty()){
                bookText.setVisibility(View.GONE);
                booktext2.setVisibility(View.GONE);
                listProgressBar.setVisibility(View.VISIBLE);
                text_search.clearFocus();
                NEW_BOOK_API = BOOKS_API.concat(get_String).concat("&startIndex="+i+"&maxResults=40");
            new BookAsync().execute(NEW_BOOK_API);}
            else{
                Toast.makeText(this, "Enter a topic to search", Toast.LENGTH_SHORT).show();
            }
    }
}
