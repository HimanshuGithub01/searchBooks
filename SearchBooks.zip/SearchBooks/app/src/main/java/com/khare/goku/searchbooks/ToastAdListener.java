package com.khare.goku.searchbooks;

import android.content.Context;

import com.google.android.gms.ads.AdListener;

public class ToastAdListener extends AdListener {
    private Context mContext;
    private String mErrorReason;

    public ToastAdListener(Context context){
        this.mContext=context;
    }

    @Override
    public void onAdLoaded() {

    }

    @Override
    public void onAdOpened() {

    }

    @Override
    public void onAdClosed() {

    }

    @Override
    public void onAdLeftApplication() {

    }

    @Override
    public void onAdFailedToLoad(int i){
    }
}