package com.khare.goku.searchbooks;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class CustomAdapter extends ArrayAdapter<com.khare.goku.searchbooks.CustomArrayList>  {

    public CustomAdapter(Context context, ArrayList<com.khare.goku.searchbooks.CustomArrayList> objects) {
        super(context, 0, objects);
    }
    CustomArrayList customArrayList;
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItemView=convertView;

        if(listItemView==null){
            listItemView= LayoutInflater.from(getContext()).inflate(R.layout.layout_view,parent,false);
        }

        customArrayList = getItem(position);
        TextView bookTitle=listItemView.findViewById(R.id.title);
        TextView bookAuthor=listItemView.findViewById(R.id.author);
        ImageView bookimage=listItemView.findViewById(R.id.imageBook);

        ImageView bookbuy=listItemView.findViewById(R.id.shop);
        Button bookinfo=listItemView.findViewById(R.id.info);
        Button bookpreview=listItemView.findViewById(R.id.preview);
        RatingBar bookRating=listItemView.findViewById(R.id.ratingBar);
        TextView  bookPrice=listItemView.findViewById(R.id.price);

        String title= customArrayList.getBook_title();
        String author=customArrayList.getBook_author();
        String image=customArrayList.getBook_image();
        Glide.with(getContext()).load(image).into(bookimage);
        String price=customArrayList.getBook_price();
        bookTitle.setText(title);
        bookAuthor.setText(author);
        bookPrice.setText(price);

        if(price.equals("Not for sale")){
        bookbuy.setVisibility(View.INVISIBLE);
        }else{
            bookbuy.setVisibility(View.VISIBLE);
        }
        bookinfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Intent.ACTION_VIEW, Uri.parse(customArrayList.getBook_info()));
                getContext().startActivity(intent);
            }
        });
        bookpreview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getContext().startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(customArrayList.getBook_preview())));
            }
        });

        bookRating.setRating(customArrayList.getBook_star());
        LayerDrawable stars = (LayerDrawable)bookRating.getProgressDrawable();
        stars.getDrawable(2).setColorFilter(Color.YELLOW, PorterDuff.Mode.SRC_ATOP);

        return listItemView;
    }
}
