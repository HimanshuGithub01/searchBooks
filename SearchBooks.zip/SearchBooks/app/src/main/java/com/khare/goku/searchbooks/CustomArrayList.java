package com.khare.goku.searchbooks;

public class CustomArrayList {
    private String book_title;
    private String book_author;
    private String book_image;
    private String book_preview;
    private String book_info;
    private String book_price;
    private String book_buy;
    private float book_star;
    private static int book_total;
    CustomArrayList(String title,String author,String image,String preview,String info,String price,String buy,float star,int total){
        book_title=title;
        book_author=author;
        book_image=image;
        book_preview=preview;
        book_info=info;
        book_price=price;
        book_buy=buy;
        book_star=star;
        book_total=total;
    }
    public String getBook_author() {
        return book_author;
    }

    public String getBook_title() {
        return book_title;
    }

    public String getBook_image() {
        return book_image;
    }

    public String getBook_preview() {return book_preview; }

    public String getBook_info() { return book_info; }

    public String getBook_price() { return book_price; }

    public String getBook_buy() { return book_buy;  }

    public float getBook_star() { return book_star; }

    public static int getBook_total() {
        return book_total;
    }
}
